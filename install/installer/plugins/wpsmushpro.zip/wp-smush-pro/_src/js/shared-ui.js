/**
 * Shared UI JS libraries. Use only what we need to keep the vendor file size smaller.
 */
require('@wpmudev/shared-ui/js/a11y-dialog');
require('@wpmudev/shared-ui/js/modals');
require('@wpmudev/shared-ui/js/notifications');