<?php
class AnimateWP {
    /**
    *contains all timelines custom posts
    */
    //public $timelines = array();

    public function __construct(){
        $this->setup_hooks();
        $this->setup_options();
        $this->load_fields();
    }

    /**
    *includes all needed javascript files and stylesheets
    */
    function include_scripts() {
        $local_debug = false;
        $min_ext = $local_debug == true ? '' : '.min';

        //Libraries
        wp_register_script( 'tweenmax-lib', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/1.19.1/TweenMax.min.js', array( 'jquery' ), true );
        wp_register_script( 'gsap-drawsvg-plugin', ANIMATEWP_LIB_URI . '/svg.min.js', array( 'jquery', 'tweenmax-lib' ), true );
        wp_register_script( 'gsap-scrollto-plugin', ANIMATEWP_LIB_URI . '/scrollto.min.js', array( 'jquery', 'tweenmax-lib' ), true );
        wp_register_script( 'gsap-splittext-plugin', ANIMATEWP_LIB_URI . '/splittext.min.js', array( 'jquery', 'tweenmax-lib' ), true );
        wp_register_script( 'scrollmagic-lib', 'https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js', array( 'jquery', 'tweenmax-lib' ), true );
        wp_register_script( 'scrollmagic-gsap-lib', ANIMATEWP_LIB_URI . '/animation.gsap'.$min_ext.'.js', array( 'jquery', 'tweenmax-lib', 'scrollmagic-lib' ), true );

        //AnimateWP JS
        wp_register_script( 'animatewp-js', ANIMATEWP_JS_URI . '/animatewp'.$min_ext.'.js', array( 'jquery', 'tweenmax-lib', 'scrollmagic-lib', 'scrollmagic-gsap-lib' ), true );
        //AnimateWP CSS
        wp_register_style( 'animatewp-css', ANIMATEWP_CSS_URI . '/animatewp'.$min_ext.'.css');

        wp_enqueue_script( 'tweenmax-lib' );
        wp_enqueue_script( 'gsap-drawsvg-plugin');
        wp_enqueue_script( 'gsap-scrollto-plugin');
        wp_enqueue_script( 'gsap-splittext-plugin');
        wp_enqueue_script( 'scrollmagic-lib' );
        wp_enqueue_script( 'scrollmagic-gsap-lib' );
        wp_enqueue_script( 'animatewp-js' );
        wp_enqueue_style( 'animatewp-css' );

        // Load options of URLs where the generated styles and scripts should not be loaded
        global $wp;
        $current_url = untrailingslashit( home_url( $wp->request ) );

        if ( function_exists('have_rows') ) {
            if ( have_rows('disable_on_urls', 'option') ) {
                while ( have_rows( 'disable_on_urls', 'option' ) ) {
                    the_row();
                    $res_url = untrailingslashit( get_sub_field('disable_url') );

                    if ( strpos($current_url , $res_url) > -1 ) {
                        return;
                    }
                }
            }

        }

        //Generated JS
        wp_register_script( 'generated-js', ANIMATEWP_JS_URI . '/generated.js', array( 'jquery', 'tweenmax-lib', 'scrollmagic-lib', 'scrollmagic-gsap-lib' ), true );
        wp_enqueue_script( 'generated-js' );
        //Generated CSS
        wp_register_style( 'generated-css', ANIMATEWP_CSS_URI . '/generated.css');
        wp_enqueue_style( 'generated-css' );
    }

    /**
    *sets up a hook which adds all other hooks as soon as the theme is loaded
    */
    public function setup_hooks(){
        add_action( 'after_setup_theme', array($this, 'add_hooks' ) );

        // Disable Quick-Edit as it breaks JSON generation
        add_filter( 'post_row_actions', array($this, 'disable_quick_edit' ), 10, 2 );
        add_filter( 'page_row_actions', array($this, 'disable_quick_edit' ), 10, 2 );
    }

    /**
    *sets up all action hooks, as the theme is now loaded
    */
    public function add_hooks() {
        add_action( 'init', array($this, 'setup_posttype' ) );

        if ( !is_admin() ) {
            add_action( "wp_enqueue_scripts", array($this, 'include_scripts') );
            add_action( "wp_enqueue_scripts", array($this, 'getTimelines') );
        }

        add_action( 'admin_enqueue_scripts', array($this, 'add_admin_scripts') );

        add_action( 'save_post', array($this, 'save_animations'), 10, 3 );
    }

    /**
     * Removes the Quick-Edit buttons for AnimateWP post type
     *
     * @param array $actions The actions of the admin table rows
     * @param post $post The post object.
     * @return The filtered actions
     */
    public function disable_quick_edit( $actions = array(), $post = null ) {

        // Abort if the post type is not "books"
        if ( ! is_post_type_archive( ANIMATEWP_PT ) ) {
            return $actions;
        }

        // Remove the Quick Edit link
        if ( isset( $actions['inline hide-if-no-js'] ) ) {
            unset( $actions['inline hide-if-no-js'] );
        }

        // Return the set of links without Quick Edit
        return $actions;
    }

    /**
     * Create option pages
     */
     public function setup_options() {
        if( function_exists('acf_add_options_page') ) {
            acf_add_options_page(array(
               'page_title' => 'AnimateWP Options',
               'menu_title' => 'AnimateWP Options',
               'menu_slug' => 'yn_animatewp_options',
               'capability' => 'manage_options',
               'position' => 1,
               'parent_slug' => 'options-general.php'
            ));
       }
     }

    /**
     * Loads the custom fields from php
     */
    public function load_fields() {
        require_once "animatewp-fields.php";
    }

    /**
     * Save post metadata when a post is saved.
     *
     * @param int $post_id The post ID.
     * @param post $post The post object.
     * @param bool $update Whether this is an existing post being updated or not.
     */
    public function save_animations( $post_id, $post, $update = false ) {

        /*
         * In production code, $slug should be set only once in the plugin,
         * preferably as a class property, rather than in each function that needs it.
         */
        $post_type = get_post_type($post_id);

        if ( ANIMATEWP_PT != $post_type ) return;
        if ( wp_is_post_revision( $post_id ) ) return;

        //array of all timelines
        $timeline = array();
        //array containing all animations of one timeline
        $animations = array();

        if( have_rows('animations', $post_id )) {
            while( have_rows('animations', $post_id) ): the_row();

            //animation data
            $animation = array();
            $animation['selectors'] = get_sub_field('animation_class');
            $animation['splittext'] = get_sub_field('awp_split_text');
            $animation['splittextvariant'] = get_sub_field('awp_splittext_selector');
            $animation['type'] = get_sub_field('animation_type');

            //easing
            $easing = get_sub_field('animation_easing');
            //no easing default
            if ($easing == 'Power0'){
                $animation['params']['ease'] = 'Power0.easeNone';
            }
            else{
                $easingvariant = get_sub_field('animation_easingvariant');
                $animation['params']['ease'] = $easing . '.' . $easingvariant;
            }

            $animation['duration'] = floatval( get_sub_field('animation_duration') );
            $animation['params']['delay'] = floatval( get_sub_field('animation_delay') );
            $animation['stagger'] = floatval( get_sub_field('stagger') );
            $animation['delay'] = get_sub_field('animation_delay');

            $repeating_enabled = get_sub_field('animation_repeating');

            if ( $repeating_enabled ) {
              if($animation['type'] == 'fromTo' || $animation['type'] == 'staggerFromTo'){
                $animation['params2']['repeat'] = intval( get_sub_field('animation_repeatnum') );
                $animation['params2']['repeatDelay'] = floatval( get_sub_field('animation_repeatdelay') );
                $animation['params2']['yoyo'] = get_sub_field('animation_yoyo');
              }
              else{
                $animation['params']['repeat'] = intval( get_sub_field('animation_repeatnum') );
                $animation['params']['repeatDelay'] = floatval( get_sub_field('animation_repeatdelay') );
                $animation['params']['yoyo'] = get_sub_field('animation_yoyo');
              }
            }

            if( have_rows('animation_properties') ) {
                while( have_rows('animation_properties') ): the_row();

                //switch based on property category
                  $property_category = get_sub_field('property_category');
                switch($property_category) {
                    case 'svg':{
                      $property = 'drawSVG';
                      $propertyvalue = get_sub_field('property_svg_value');
                      break;
                    }
                    case 'scrollTo':{
                      $property = 'scrollTo';
                      $scrollto_y_val = get_sub_field('animation_scrollto_y_destination');
                      $scrollto_x_val = get_sub_field('animation_scrollto_x_destination');
                      $scrollto_y_offset = get_sub_field('animation_scrollto_y_offset');
                      $scrollto_x_offset = get_sub_field('animation_scrollto_x_offset');
                      $propertyvalue = array();
                      //autokill false - if autokill is true the scrolling only works once per pageload
                      $propertyvalue['autoKill'] = false;
                      if($scrollto_y_val){
                        //check if 0 is the wished value
                        if($scrollto_y_val == '0'){
                          $propertyvalue['y'] = 0;
                        }
                        //if intval fails there is probably a text selector specified, take it
                        else if(intval($scrollto_y_val) == 0){
                          $propertyvalue['y'] = $scrollto_y_val;
                        }
                        //parse the value as int
                        else{
                          $propertyvalue['y'] = intval($scrollto_y_val);
                        }
                      }
                      if($scrollto_x_val){
                        //check if 0 is the wished value
                        if($scrollto_x_val == '0'){
                          $propertyvalue['x'] = 0;
                        }
                        //if intval fails there is probably a text selector specified, take it
                        else if(intval($scrollto_x_val) == 0){
                          $propertyvalue['x'] = $scrollto_x_val;
                        }
                        //parse the value as int
                        else{
                          $propertyvalue['x'] = intval($scrollto_x_val);
                        }
                      }
                      if($scrollto_y_offset != 0){
                        $propertyvalue['offsetY'] = intval($scrollto_y_offset);
                      }
                      if($scrollto_x_offset != 0){
                        $propertyvalue['offsetX'] = intval($scrollto_x_offset);
                      }
                      break;
                    }
                    case 'text': {
                        $property = get_sub_field('property_text');
                        switch($property){
                          case 'color':{
                            $propertyvalue = get_sub_field('property_fontcolor');
                            break;
                          }
                          case 'fontSize':{
                            $propertyvalue = get_sub_field('property_fontsize');
                            break;
                          }
                          case 'letterSpacing':{
                            $propertyvalue = get_sub_field('property_letterspacing');
                            break;
                          }
                          case 'lineHeight':{
                            $propertyvalue = get_sub_field('property_lineheight');
                            break;
                          }
                          case 'wordSpacing':{
                            $propertyvalue = get_sub_field('property_wordspacing');
                            break;
                          }
                          case 'textShadow':{
                            $propertyvalue = get_sub_field('property_textshadow');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                      }
                    case 'box': {
                        $property = get_sub_field('property_box');
                        switch($property){
                          case 'scale':{
                            $propertyvalue = get_sub_field('property_box_scale');
                            break;
                          }
                          case 'autoAlpha':{
                            $propertyvalue = get_sub_field('property_box_autoalpha');
                            break;
                          }
                          case 'backgroundColor':{
                            $propertyvalue = get_sub_field('property_box_bgcolor');
                            break;
                          }
                          case 'backgroundPosition':{
                            $propertyvalue = get_sub_field('property_box_bgposition');
                            break;
                          }
                          case 'backgroundSize':{
                            $propertyvalue = get_sub_field('property_box_bgsize');
                            break;
                          }
                          case 'boxShadow':{
                            $propertyvalue = get_sub_field('property_box_boxshadow');
                            break;
                          }
                          case 'height':{
                            $propertyvalue = get_sub_field('property_box_height');
                            break;
                          }
                          case 'width':{
                            $propertyvalue = get_sub_field('property_box_width');
                            break;
                          }
                          case 'margin':{
                            $propertyvalue = get_sub_field('property_box_margin');
                            break;
                          }
                          case 'padding':{
                            $propertyvalue = get_sub_field('property_box_padding');
                            break;
                          }
                          case 'borderColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor');
                            break;
                          }
                          case 'borderTopColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_top');
                            break;
                          }
                          case 'borderRightColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_right');
                            break;
                          }
                          case 'borderBottomColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_bottom');
                            break;
                          }
                          case 'borderLeftColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_left');
                            break;
                          }
                          case 'borderWidth':{
                            $propertyvalue = get_sub_field('property_box_borderwidth');
                            break;
                          }
                          case 'borderRadius':{
                            $propertyvalue = get_sub_field('property_box_borderradius');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                      }
                    case 'postrans': {
                        $property = get_sub_field('property_postrans');
                        switch($property){
                          case 'x':{
                            $propertyvalue = get_sub_field('property_xy_position');
                            break;
                          }
                          case 'y':{
                            $propertyvalue = get_sub_field('property_xy_position');
                            break;
                          }
                          case 'rotation':{
                          $propertyvalue = get_sub_field('property_rotation');
                            break;
                          }
                          case 'rotationX':{
                          $propertyvalue = get_sub_field('property_rotation_x');
                            break;
                          }
                          case 'rotationY':{
                          $propertyvalue = get_sub_field('property_rotation_y');
                            break;
                          }
                          case 'scaleX':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'scaleY':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'scale':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'skewX':{
                            $propertyvalue = get_sub_field('property_skew');
                            break;
                          }
                          case 'skewY':{
                            $propertyvalue = get_sub_field('property_skew');
                            break;
                          }
                          case 'top':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'right':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'bottom':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'left':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'zIndex':{
                            $propertyvalue = get_sub_field('property_zindex');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                      }
                    case 'custom': {
                        $property = get_sub_field('property_custom_key');
                        $propertyvalue = get_sub_field('property_custom_value');
                        break;
                    }

                    default: {
                        //$property = 'error';
                        //$propertyvalue = 'error';
                        break;
                      }
                  }
                  $animation['params'][$property] = $propertyvalue;

                endwhile;
            }

            //if animation type is fromTo or staggerFromTo get second set of property values
            if( ($animation['type'] == 'fromTo' || $animation['type'] == 'staggerFromTo')
            && have_rows('animation_properties_fromto_dest') ) {
                while( have_rows('animation_properties_fromto_dest') ): the_row();

                //switch based on property category
                  $property_category = get_sub_field('property_category');
                switch($property_category) {
                    case 'svg':{
                        $property = 'drawSVG';
                        $propertyvalue = get_sub_field('property_svg_value');
                        break;
                    }
                    case 'text': {
                        $property = get_sub_field('property_text');
                        switch($property){
                          case 'color':{
                            $propertyvalue = get_sub_field('property_fontcolor');
                            break;
                          }
                          case 'fontSize':{
                            $propertyvalue = get_sub_field('property_fontsize');
                            break;
                          }
                          case 'letterSpacing':{
                            $propertyvalue = get_sub_field('property_letterspacing');
                            break;
                          }
                          case 'lineHeight':{
                            $propertyvalue = get_sub_field('property_lineheight');
                            break;
                          }
                          case 'wordSpacing':{
                            $propertyvalue = get_sub_field('property_wordspacing');
                            break;
                          }
                          case 'textShadow':{
                            $propertyvalue = get_sub_field('property_textshadow');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                    }
                    case 'box': {
                        $property = get_sub_field('property_box');
                        switch($property){
                          case 'scale':{
                            $propertyvalue = get_sub_field('property_box_scale');
                            break;
                          }
                          case 'autoAlpha':{
                            $propertyvalue = get_sub_field('property_box_autoalpha');
                            break;
                          }
                          case 'backgroundColor':{
                            $propertyvalue = get_sub_field('property_box_bgcolor');
                            break;
                          }
                          case 'backgroundPosition':{
                            $propertyvalue = get_sub_field('property_box_bgposition');
                            break;
                          }
                          case 'backgroundSize':{
                            $propertyvalue = get_sub_field('property_box_bgsize');
                            break;
                          }
                          case 'boxShadow':{
                            $propertyvalue = get_sub_field('property_box_boxshadow');
                            break;
                          }
                          case 'height':{
                            $propertyvalue = get_sub_field('property_box_height');
                            break;
                          }
                          case 'width':{
                            $propertyvalue = get_sub_field('property_box_width');
                            break;
                          }
                          case 'margin':{
                            $propertyvalue = get_sub_field('property_box_margin');
                            break;
                          }
                          case 'padding':{
                            $propertyvalue = get_sub_field('property_box_padding');
                            break;
                          }
                          case 'borderColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor');
                            break;
                          }
                          case 'borderTopColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_top');
                            break;
                          }
                          case 'borderRightColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_right');
                            break;
                          }
                          case 'borderBottomColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_bottom');
                            break;
                          }
                          case 'borderLeftColor':{
                            $propertyvalue = get_sub_field('property_box_bordercolor_left');
                            break;
                          }
                          case 'borderWidth':{
                            $propertyvalue = get_sub_field('property_box_borderwidth');
                            break;
                          }
                          case 'borderRadius':{
                            $propertyvalue = get_sub_field('property_box_borderradius');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                    }
                    case 'postrans': {
                        $property = get_sub_field('property_postrans');
                        switch($property){
                          case 'x':{
                            $propertyvalue = get_sub_field('property_xy_position');
                            break;
                          }
                          case 'y':{
                            $propertyvalue = get_sub_field('property_xy_position');
                            break;
                          }
                          case 'rotation':{
                          $propertyvalue = get_sub_field('property_rotation');
                            break;
                          }
                          case 'rotationX':{
                          $propertyvalue = get_sub_field('property_rotation_x');
                            break;
                          }
                          case 'rotationY':{
                          $propertyvalue = get_sub_field('property_rotation_y');
                            break;
                          }
                          case 'scaleX':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'scaleY':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'scale':{
                            $propertyvalue = get_sub_field('property_scale');
                            break;
                          }
                          case 'skewX':{
                            $propertyvalue = get_sub_field('property_skew');
                            break;
                          }
                          case 'skewY':{
                            $propertyvalue = get_sub_field('property_skew');
                            break;
                          }
                          case 'top':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'right':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'bottom':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'left':{
                            $propertyvalue = get_sub_field('property_abs_position');
                            break;
                          }
                          case 'zIndex':{
                            $propertyvalue = get_sub_field('property_zindex');
                            break;
                          }
                          default:{
                            break;
                          }
                        }
                        break;
                    }
                    case 'custom': {
                        $property = get_sub_field('property_custom_key2');
                        $propertyvalue = get_sub_field('property_custom_value2');
                        break;
                    }
                    default: {
                        //$property = 'error';
                        //$propertyvalue = 'error';
                        break;
                      }

                  }
                  $animation['params2'][$property] = $propertyvalue;

                endwhile;
            }

            //add this animation to the animations array
            $animations[] = $animation;
            endwhile;
        }

        $timeline['name'] = $post->post_title;
        $timeline['animations'] = $animations;
        //get the timeline repeating options
        if(get_field('repeating_activated', $post->ID))
        {
          $repeating['repeat'] = intval(get_field('repeating_times', $post_id));
          $repeating['repeatDelay'] = floatval(get_field('repeating_delay', $post_id));
          $repeating['yoyo'] = get_field('tl_repeating_yoyo', $post_id);
        }


        $trigger['trigger'] = get_field('trigger');
        $trigger['custom'] = get_field('custom_trigger');
        $trigger['selector'] = get_field('trigger_selector');
        $trigger['scrollTriggerPosition'] = get_field('scroll_trigger_position');
        $trigger['scrollTriggerOffset'] = intval(get_field('scroll_trigger_offset'));
        $trigger['scrollTriggerReverse'] = get_field('scroll_trigger_reverse');

        $trigger['scrollbarBased'] = get_field('tween_based_on_scrollbar');
        $trigger['scrollSpeed'] = intval(get_field('trigger_scroll_speed'));
        $trigger['windowSize'] = intval(get_field('trigger_minimum_window_size'));
        $trigger['pauseOnMouseLeave'] = get_field('trigger_pause_on_mouse_leave');
        $trigger['continueOnMouseReEnter'] = get_field('trigger_continue_on_mouse_reenter');

        //set scroll speed to 0 if scrollTriggerReverse is false
        if(!$trigger['scrollTriggerReverse']){
            $trigger['scrollTriggerReverse'] = 0;
        }
        //set scroll speed to 0 if scrollbarBased is false
        if(!$trigger['scrollbarBased']){
          $trigger['scrollSpeed'] = 0;
        }

        $timeline['trigger'] = $trigger;

        // Don't start timelines automatically
        if($trigger['trigger'] != 'scroll'){
          $repeating['paused'] = true;
        }
        else{
          $repeating['paused'] = false;
        }

        //get timeline control fields
        $controls['play'] = get_field('tl_play_selectors');
        $controls['pause'] = get_field('tl_pause_selectors');
        $controls['restart'] = get_field('tl_restart_selectors');
        $controls['progressslider'] = get_field('tl_progressslider_selectors');

        // properties for TimelineMax
        $timeline['properties'] = $repeating;
        $timeline['controls'] = $controls;


        //wp_die( $post_id );
        update_post_meta( $post_id, ANIMATEWP_META_COMPILED_JSON, $timeline );

        //create css file for fromTo and staggerFromTo animations
        $cssargs = array(
            'posts_per_page'   => -1,
            'meta_key'         => '',
            'meta_value'       => '',
            'post_type'        => ANIMATEWP_PT,
            'post_status'      => 'publish',
            'suppress_filters' => true
        );
        $css_posts_array = get_posts($cssargs);
        //array of all timelines
        $csstimelines = array();
        $cssselectors = array();

        foreach($css_posts_array as $csspost) {
          if( have_rows('animations', $csspost->ID )) {
            while( have_rows('animations', $csspost->ID) ): the_row();
            $type = get_sub_field('animation_type');
            if($type == 'from' || $type == 'fromTo' || $type == 'staggerFrom' || $type == 'staggerFromTo'){
              $selectors_string = get_sub_field('animation_class');
              //if there are multiple selectors, iterate over the individual selectors and add them to array
              if( strpos($selectors_string, ',') !== false ) {
                $selectors = explode(',', get_sub_field('animation_class'));
                foreach($selectors as $selector){
                  $cssselectors[] = $selector;
                }
              }
              else{
                $cssselectors[] = $selectors_string;
              }
            }
            endwhile;
          }
        }
        if(!empty($cssselectors)){
          $cssstring = implode(',', $cssselectors);
          $cssfinalstring = $cssstring . '{visibility:hidden;}';
          $cssfile = fopen(ANIMATEWP_PATH . "/assets/css/generated.css", "w") or error_log('Unable to open file!');
          fwrite($cssfile, $cssfinalstring);
          fclose($cssfile);

          $jsstring = 'jQuery( document ).ready(function($) {TweenMax.set("'.$cssstring.'", {visibility:"visible"});});';
          $jsfile = fopen(ANIMATEWP_PATH . "/assets/js/generated.js", "w") or error_log("Unable to open file!");
          fwrite($jsfile, $jsstring);
          fclose($jsfile);
        }
    }


    /**
    *Enqueues Admin scripts
    */
    public function add_admin_scripts() {
        global $post_type;

        $local_debug = false;

        if ( is_admin() && $post_type == ANIMATEWP_PT ) {
            $min_ext = $local_debug == true ? '' : '.min';

            wp_register_style( 'animatewp-admin-css', ANIMATEWP_CSS_URI.'/animatewp-admin'.$min_ext.'.css' );
            wp_enqueue_style( 'animatewp-admin-css' );
        }
    }

    /**
    *sets up the custom post type used for animatewp
    */
    public function setup_posttype() {
        register_post_type( ANIMATEWP_PT,
            array(
                'labels' => array(
                    'name' => __( 'AnimateWP' ),
                    'singular_name' => __( 'AnimateWP' ),
                    'menu_name'           => __( 'AnimateWP', 'animatewp' ),
                    'parent_item_colon'   => __( 'Parent AnimateWP', 'animatewp' ),
                    'all_items'           => __( 'All Timelines', 'animatewp' ),
                    'view_item'           => __( 'View Timelines', 'animatewp' ),
                    'add_new_item'        => __( 'Add New Timeline', 'animatewp' ),
                    'add_new'             => __( 'Add New Timeline', 'animatewp' ),
                    'edit_item'           => __( 'Edit Timeline', 'animatewp' ),
                    'update_item'         => __( 'Update Timeline', 'animatewp' ),
                    'search_items'        => __( 'Search Timelines', 'animatewp' ),
                    'not_found'           => __( 'Not Found', 'animatewp' ),
                    'not_found_in_trash'  => __( 'Not found in Trash', 'animatewp' ),
                ),
                'public' => true,
                'has_archive' => true,
                'menu_position' => 3,
                'menu_icon' => 'dashicons-schedule',
            )
        );
    }

    function getTimelines(){
        $args = array(
            'posts_per_page'   => -1,
            'meta_key'         => '',
            'meta_value'       => '',
            'post_type'        => ANIMATEWP_PT,
            'post_status'      => 'publish',
            'suppress_filters' => true
        );
        $posts_array = get_posts($args);
        //array of all timelines
        $timelines = array();

        foreach($posts_array as $post) {
            //array containing all animations of one timeline
            $timelines[] = get_post_meta($post->ID, ANIMATEWP_META_COMPILED_JSON, true);
        }


        //make our timelines available in the animatewp javascript
        wp_localize_script('animatewp-js', 'timelines', json_encode($timelines));
    }
}
