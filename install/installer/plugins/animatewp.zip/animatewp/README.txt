=== AnimateWP (IT for your needs) ===
Contributors: IT for your needs OG


== Installation ==

Simply drop the whole animatewp folder into your wp-content/plugins folder or upload it as ZIP through the WordPress backend.


== Information ==

If you need any help with the plugin or searching for the documentation, please visit:

http://animatewp.yourneeds.at/docs


Thanks!
IT for your needs

Changelog:
1.1.3 - Added option to set reverse functionality for scroll events to apply timelines only once
1.1.2 - Added option to disable the loading of generated JS and CSS files to prevent invisible page parts when using certain page builder
1.1.1 - Fixed a bug with SplitText, if the selected element doesn't exist on the current page.
1.1.0 - New Animation Property: SplitText
		Allows you to split text into characters, words and lines automatically and animate each individually.
		See https://animatewp.yourneeds.at/docs/#splittext for more information
________________________________________________________________________________________________________
1.0.1 - New Animation Property: ScrollTo
		Allows you to scroll the window (or a container with scrollbar) to a specified position.
		See https://animatewp.yourneeds.at/animatable-properties/#scroll-to for more information
